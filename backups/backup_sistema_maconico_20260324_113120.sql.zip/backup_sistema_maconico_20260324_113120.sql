-- Backup do banco sistema_maconico - 24/03/2026 11:31:20
-- Gerado pelo Sistema Maçônico

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';

-- Dados da tabela: alertas_presenca
DELETE FROM alertas_presenca;

-- Dados da tabela: anexos_ata
DELETE FROM anexos_ata;

-- Dados da tabela: assinaturas_ata
DELETE FROM assinaturas_ata;

INSERT INTO assinaturas_ata (id, ata_id, obreiro_id, cargo_id, assinatura, data_assinatura, ip_assinatura, hash_assinatura, validada) VALUES (1, 1, 1, NULL, NULL, '2026-03-23 15:39:11', '127.0.0.1', NULL, 0);
INSERT INTO assinaturas_ata (id, ata_id, obreiro_id, cargo_id, assinatura, data_assinatura, ip_assinatura, hash_assinatura, validada) VALUES (2, 2, 7, NULL, NULL, '2026-03-23 23:25:51', '127.0.0.1', NULL, 0);

-- Dados da tabela: atas
DELETE FROM atas;

INSERT INTO atas (id, reuniao_id, conteudo, redator_id, aprovada, data_aprovacao, versao, arquivo_pdf, data_criacao, numero_ata, ano_ata, tipo_ata, redator_nome, secretario_id, aprovada_em, aprovada_por, observacoes_aprovacao, modelo_ata, assinaturas, hash_documento, data_impressao, impresso_por) VALUES (1, 2, '## CABEÇALHO

- Abertura
- Verificacao de quorum
- Leitura da ata anterior

---

## EXPEDIENTE

- Comunicacoes
- Propostas
- Informacoes

---

## ORDEM DO DIA

- Assuntos em pauta
- Votacoes
- Deliberacoes

---
fdgfd
## ENCERRAMENTO

- Palavra final
- Marcacao proxima reuniao
- Encerramento

', 1, 0, NULL, 3, NULL, '2026-03-23 15:35:00', 1, 2026, 'Exaltação', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO atas (id, reuniao_id, conteudo, redator_id, aprovada, data_aprovacao, versao, arquivo_pdf, data_criacao, numero_ata, ano_ata, tipo_ata, redator_nome, secretario_id, aprovada_em, aprovada_por, observacoes_aprovacao, modelo_ata, assinaturas, hash_documento, data_impressao, impresso_por) VALUES (2, 4, 'asdfasfdasdfasdf', 1, 0, NULL, 1, NULL, '2026-03-23 16:20:55', 2, 2026, 'Ordinária', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- Dados da tabela: candidatos
DELETE FROM candidatos;

-- Dados da tabela: cargos
DELETE FROM cargos;

INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (1, 'Venerável Mestre', 'VM', 3, 1, 'Presidente da loja', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (2, '1º Vigilante', '1V', 3, 2, 'Primeiro vigilante', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (3, '2º Vigilante', '2V', 3, 3, 'Segundo vigilante', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (4, 'Orador', 'OR', 3, 4, 'Orador da loja', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (5, 'Secretário', 'SEC', 2, 5, 'Secretário', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (6, 'Tesoureiro', 'TES', 2, 6, 'Tesoureiro', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (7, 'Chanceler', 'CHAN', 2, 7, 'Guardião do templo', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (8, 'Mestre de Cerimônias', 'MC', 2, 8, 'Cerimonialista', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (9, '1º Diácono', '1D', 2, 9, 'Primeiro diácono', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (10, '2º Diácono', '2D', 2, 10, 'Segundo diácono', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (11, 'Cobridor', 'COB', 2, 11, 'Cobridor interno', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (12, 'Porta-Estandarte', 'PE', 1, 12, 'Porta estandarte', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (13, 'Porta-Espada', 'PESP', 1, 13, 'Porta espada', 1);
INSERT INTO cargos (id, nome, sigla, grau_minimo, ordem, descricao, ativo) VALUES (14, 'Hospitaleiro', 'HOSP', 1, 14, 'Responsável pelo ágape ', 1);

-- Dados da tabela: categorias_documentos
DELETE FROM categorias_documentos;

INSERT INTO categorias_documentos (id, nome, descricao, icone, ativo) VALUES (1, 'documentos_pessoais', 'Documentos pessoais do obreiro', 'fa-id-card', 1);
INSERT INTO categorias_documentos (id, nome, descricao, icone, ativo) VALUES (2, 'certificados', 'Certificados de graus e cursos', 'fa-certificate', 1);
INSERT INTO categorias_documentos (id, nome, descricao, icone, ativo) VALUES (3, 'atas', 'Atas de reuniões', 'fa-file-alt', 1);
INSERT INTO categorias_documentos (id, nome, descricao, icone, ativo) VALUES (4, 'correspondencias', 'Correspondências oficiais', 'fa-envelope', 1);
INSERT INTO categorias_documentos (id, nome, descricao, icone, ativo) VALUES (5, 'outros', 'Outros documentos', 'fa-file', 1);

-- Dados da tabela: categorias_sugestoes
DELETE FROM categorias_sugestoes;

INSERT INTO categorias_sugestoes (id, nome, descricao, ativo) VALUES (1, 'melhoria_sistema', 'Melhorias no sistema', 1);
INSERT INTO categorias_sugestoes (id, nome, descricao, ativo) VALUES (2, 'nova_funcionalidade', 'Nova funcionalidade', 1);
INSERT INTO categorias_sugestoes (id, nome, descricao, ativo) VALUES (3, 'correcao_bug', 'Correção de bug', 1);
INSERT INTO categorias_sugestoes (id, nome, descricao, ativo) VALUES (4, 'documentacao', 'Documentação', 1);
INSERT INTO categorias_sugestoes (id, nome, descricao, ativo) VALUES (5, 'seguranca', 'Segurança', 1);
INSERT INTO categorias_sugestoes (id, nome, descricao, ativo) VALUES (6, 'outros', 'Outros', 1);

-- Dados da tabela: comentarios_sugestao
DELETE FROM comentarios_sugestao;

-- Dados da tabela: comunicados
DELETE FROM comunicados;

INSERT INTO comunicados (id, titulo, conteudo, tipo, prioridade, data_inicio, data_fim, ativo, criado_por, data_criacao) VALUES (1, 'Aviso geral', 'Aviso geral pra galera', 'aviso', 'importante', 2026-03-23, NULL, 1, 1, '2026-03-23 18:04:25');

-- Dados da tabela: condecoracoes_obreiro
DELETE FROM condecoracoes_obreiro;

INSERT INTO condecoracoes_obreiro (id, obreiro_id, tipo_id, data_concessao, data_validade, concedido_por, motivo, numero_registro, observacoes, created_at) VALUES (1, 6, 5, 2026-03-23, NULL, 1, '', '', '', '2026-03-23 19:38:49');

-- Dados da tabela: documentos_obreiro
DELETE FROM documentos_obreiro;

-- Dados da tabela: email_settings
DELETE FROM email_settings;

INSERT INTO email_settings (id, server, port, use_tls, username, password, sender, sender_name, active, use_ssl, updated_at) VALUES (1, 'smtp.gmail.com', 465, 0, 'jurandibarros@gmail.com', 'Jmtl$16131218', 'secretaria.bicentenario4739@gmail.com', 'Sistema Maçônico', 0, 1, '2026-03-23 22:00:14');
INSERT INTO email_settings (id, server, port, use_tls, username, password, sender, sender_name, active, use_ssl, updated_at) VALUES (2, 'smtp.gmail.com', 465, 0, 'jurandibarros@gmail.com', 'Jmtl$16131218', 'jurandibarros@gmail.com', 'Sistema Maçônico', 0, 1, '2026-03-23 22:00:14');
INSERT INTO email_settings (id, server, port, use_tls, username, password, sender, sender_name, active, use_ssl, updated_at) VALUES (3, 'smtp.gmail.com', 465, 0, 'secretaria.bicentenario4739@gmail.com', 'Sec@4739', 'secretaria.bicentenario4739@gmail.com', 'Sistema Maçônico', 0, 1, '2026-03-23 22:00:14');
INSERT INTO email_settings (id, server, port, use_tls, username, password, sender, sender_name, active, use_ssl, updated_at) VALUES (4, 'smtp.gmail.com', 587, 1, 'secretaria.bicentenario4739@gmail.com', 'fwwc ywts ubde cglm', 'secretaria.bicentenario4739@gmail.com', 'Sistema Maçônico', 0, 0, '2026-03-23 22:00:14');
INSERT INTO email_settings (id, server, port, use_tls, username, password, sender, sender_name, active, use_ssl, updated_at) VALUES (5, 'smtp.outlook.com', 587, 1, 'jurandibarros@homail.com', 'Jmtl$16131218', 'jurandibarros@hotmail.com', 'Sistema Maçônico', 0, 0, '2026-03-23 22:32:51');
INSERT INTO email_settings (id, server, port, use_tls, username, password, sender, sender_name, active, use_ssl, updated_at) VALUES (6, 'smtp.hotmail.com', 587, 1, 'jurandibarros@homail.com', 'Jmtl$16131218', 'jurandibarros@hotmail.com', 'Sistema Maçônico', 0, 0, '2026-03-23 22:33:07');
INSERT INTO email_settings (id, server, port, use_tls, username, password, sender, sender_name, active, use_ssl, updated_at) VALUES (7, 'smtp.outlook.com', 587, 1, 'jurandibarros@homail.com', 'Jmtl$16131218', 'jurandibarros@hotmail.com', 'Sistema Maçônico', 1, 0, '2026-03-23 22:34:16');

-- Dados da tabela: estatisticas_presenca
DELETE FROM estatisticas_presenca;

-- Dados da tabela: familiares
DELETE FROM familiares;

INSERT INTO familiares (id, obreiro_id, nome, parentesco, data_nascimento, telefone, email, observacoes, receber_notificacoes, created_at, created_by) VALUES (1, 1, 'Marta Nogueira Barros', 'esposa', 1975-02-13, '', '', '', 1, '2026-03-23 19:17:07', 1);

-- Dados da tabela: graus
DELETE FROM graus;

INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (1, 'Aprendiz', 'Primeiro grau da Maçonaria Simbólica', 1, 1, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (2, 'Companheiro', 'Segundo grau da Maçonaria Simbólica', 2, 2, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (3, 'Mestre', 'Terceiro grau da Maçonaria Simbólica', 3, 3, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (4, 'Mestre Instalado', 'Grau conferido ao Venerável Mestre após seu mandato', 4, 4, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (5, 'Arquiteto Real', 'Grau do Rito de York', 4, 5, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (6, 'Soberano Grande Inspetor Geral', '33º grau do Rito Escocês', 4, 6, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (7, 'Mestre Perfeito', 'Grau intermediário do Rito Escocês', 4, 7, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (8, 'Eleito dos Nove', 'Grau do Rito Escocês', 4, 8, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (9, 'Mestre da Maçonaria Real', 'Grau do Rito de York', 4, 9, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (10, 'Cavaleiro Rosa-Cruz', 'Grau filosófico', 4, 10, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (11, 'Cavaleiro Kadosch', '30º grau do Rito Escocês', 4, 11, 1, '2026-03-23 17:18:43', NULL);
INSERT INTO graus (id, nome, descricao, nivel, ordem, ativo, created_at, created_by) VALUES (12, 'Grande Escocês', 'Grau superior', 4, 12, 1, '2026-03-23 17:18:43', NULL);

-- Dados da tabela: historico_graus
DELETE FROM historico_graus;

INSERT INTO historico_graus (id, obreiro_id, grau, data, observacao, grau_id) VALUES (1, 6, 3, 2026-03-24, 'Atualização de grau para Mestre', NULL);
INSERT INTO historico_graus (id, obreiro_id, grau, data, observacao, grau_id) VALUES (2, 6, 4, 2026-03-24, 'Atualização de grau para Mestre Instalado', NULL);
INSERT INTO historico_graus (id, obreiro_id, grau, data, observacao, grau_id) VALUES (3, 6, 3, 2026-03-24, 'Atualização de grau para Mestre', NULL);
INSERT INTO historico_graus (id, obreiro_id, grau, data, observacao, grau_id) VALUES (4, 6, 4, 2026-03-24, 'Atualização de grau para Mestre Instalado', NULL);
INSERT INTO historico_graus (id, obreiro_id, grau, data, observacao, grau_id) VALUES (5, 6, 3, 2026-03-24, 'Atualização de grau para Mestre', NULL);

-- Dados da tabela: logs_auditoria
DELETE FROM logs_auditoria;

INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (4, 1, 'Administrador', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:22:00');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (5, 1, 'Administrador', 'excluir', 'loja', 1, '{"id": 1, "nome": "ARLS Estrela do Oriente", "numero": "123", "oriente": "Oriente de São Paulo", "cidade": "São Paulo", "estado": "SP", "data_fundacao": null}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:35:42');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (6, 1, 'Administrador', 'criar', 'loja', 0, NULL, '{"nome": "Bicentenário", "numero": "4739"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:36:25');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (7, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 1, '{"id": 1, "usuario": "admin", "senha_hash": "scrypt:32768:8:1$SrL2i1H9QSyC2F90$576e559fa8e1c0a01bbf9f06a6dee06260f2e1431e9df69b08aaf25a9cbd5a62172cd792d1d30ab1da76329f4b62f1fe3f334778fd8d90121ca3757e8616bcb3", "tipo": "admin", "data_cadastro": "2026-03-23 13:26:44", "nome_completo": "Administrador", "nome_maconico": null, "cim_numero": null, "grau_atual": 1, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": null, "email": null, "endereco": null, "loja_nome": null, "loja_numero": null, "loja_orient": null, "ativo": 1}', '{"nome": "Jurandi de Melo Barros", "email": "jurandibarros@gmail.com", "telefone": "(61) 99368-1248"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:40:23');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (8, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 1, '{"id": 1, "usuario": "admin", "senha_hash": "scrypt:32768:8:1$SrL2i1H9QSyC2F90$576e559fa8e1c0a01bbf9f06a6dee06260f2e1431e9df69b08aaf25a9cbd5a62172cd792d1d30ab1da76329f4b62f1fe3f334778fd8d90121ca3757e8616bcb3", "tipo": "admin", "data_cadastro": "2026-03-23 13:26:44", "nome_completo": "Jurandi de Melo Barros", "nome_maconico": "Jurandi", "cim_numero": "339.652", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "(61) 99368-1248", "email": "jurandibarros@gmail.com", "endereco": "QNQ 02 Conjunto 18 Casa 19", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1}', '{"nome": "Jurandi de Melo Barros", "email": "jurandibarros@gmail.com", "telefone": "(61) 99368-1248"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:40:33');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (9, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 1, '{"id": 1, "usuario": "admin", "senha_hash": "scrypt:32768:8:1$SrL2i1H9QSyC2F90$576e559fa8e1c0a01bbf9f06a6dee06260f2e1431e9df69b08aaf25a9cbd5a62172cd792d1d30ab1da76329f4b62f1fe3f334778fd8d90121ca3757e8616bcb3", "tipo": "admin", "data_cadastro": "2026-03-23 13:26:44", "nome_completo": "Jurandi de Melo Barros", "nome_maconico": "Jurandi", "cim_numero": "339.652", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "(61) 99368-1248", "email": "jurandibarros@gmail.com", "endereco": "QNQ 02 Conjunto 18 Casa 19", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1}', '{"nome": "Jurandi de Melo Barros", "email": "jurandibarros@gmail.com", "telefone": "(61) 99368-1248"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:41:56');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (10, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 1, '{"id": 1, "usuario": "admin", "senha_hash": "scrypt:32768:8:1$SrL2i1H9QSyC2F90$576e559fa8e1c0a01bbf9f06a6dee06260f2e1431e9df69b08aaf25a9cbd5a62172cd792d1d30ab1da76329f4b62f1fe3f334778fd8d90121ca3757e8616bcb3", "tipo": "admin", "data_cadastro": "2026-03-23 13:26:44", "nome_completo": "Jurandi de Melo Barros", "nome_maconico": "Jurandi", "cim_numero": "339.652", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "(61) 99368-1248", "email": "jurandibarros@gmail.com", "endereco": "QNQ 02 Conjunto 18 Casa 19", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1}', '{"nome": "Jurandi de Melo Barros", "email": "jurandibarros@gmail.com", "telefone": "(61) 99368-1248"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:42:30');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (11, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 1, '{"id": 1, "usuario": "admin", "senha_hash": "scrypt:32768:8:1$SrL2i1H9QSyC2F90$576e559fa8e1c0a01bbf9f06a6dee06260f2e1431e9df69b08aaf25a9cbd5a62172cd792d1d30ab1da76329f4b62f1fe3f334778fd8d90121ca3757e8616bcb3", "tipo": "admin", "data_cadastro": "2026-03-23 13:26:44", "nome_completo": "Jurandi de Melo Barros", "nome_maconico": "Jurandi", "cim_numero": "339.652", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "(61) 99368-1248", "email": "jurandibarros@gmail.com", "endereco": "QNQ 02 Conjunto 18 Casa 19", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1}', '{"nome": "Jurandi de Melo Barros", "email": "jurandibarros@gmail.com", "telefone": "(61) 99368-1248"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:48:25');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (12, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 1, '{"id": 1, "usuario": "admin", "senha_hash": "scrypt:32768:8:1$SrL2i1H9QSyC2F90$576e559fa8e1c0a01bbf9f06a6dee06260f2e1431e9df69b08aaf25a9cbd5a62172cd792d1d30ab1da76329f4b62f1fe3f334778fd8d90121ca3757e8616bcb3", "tipo": "admin", "data_cadastro": "2026-03-23 13:26:44", "nome_completo": "Jurandi de Melo Barros", "nome_maconico": "Jurandi", "cim_numero": "339.652", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "(61) 99368-1248", "email": "jurandibarros@gmail.com", "endereco": "QNQ 02 Conjunto 18 Casa 19", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1}', '{"nome": "Jurandi de Melo Barros", "email": "jurandibarros@gmail.com", "telefone": "(61) 99368-1248"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 14:48:37');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (13, 1, 'Jurandi de Melo Barros', 'criar', 'reuniao', 0, NULL, '{"titulo": "Sessão Ordinária", "data": "2026-03-23", "tipo": "Administrativa"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:15:43');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (14, 1, 'Jurandi de Melo Barros', 'editar', 'reuniao', 1, '{"id": 1, "titulo": "Sessão Ordinária", "tipo": "Administrativa", "grau": null, "data": "2026-03-23", "hora_inicio": "19:30:00", "hora_termino": "22:00:00", "local": null, "loja_id": 2, "pauta": null, "observacoes": null, "status": "agendada", "data_criacao": "2026-03-23 15:15:43.740326", "criado_por": 1}', '{"titulo": "Sessão Ordinária", "data": "2026-03-23", "status": "agendada"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:22:28');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (41, 7, 'Renato Maximino', 'login', 'usuarios', 7, NULL, '{"usuario": "Renato"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:01:19');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (42, 7, 'Renato Maximino', 'logout', 'usuarios', 7, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:02:32');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (15, 1, 'Jurandi de Melo Barros', 'excluir', 'reuniao', 1, '{"id": 1, "titulo": "Sessão Ordinária", "tipo": "Administrativa", "grau": null, "data": "2026-03-23", "hora_inicio": "19:30:00", "hora_termino": "22:00:00", "local": null, "loja_id": 2, "pauta": "Assunto qualquer", "observacoes": null, "status": "agendada", "data_criacao": "2026-03-23 15:15:43.740326", "criado_por": 1}', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:22:41');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (16, 1, 'Jurandi de Melo Barros', 'criar', 'reuniao', 0, NULL, '{"titulo": "Sessão Ordinária", "data": "2026-03-23", "tipo": "Exaltação"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:23:28');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (17, 1, 'Jurandi de Melo Barros', 'alterar_status', 'reuniao', 2, '{"status": "agendada"}', '{"status": "realizada"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:28:00');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (18, 1, 'Jurandi de Melo Barros', 'criar', 'ata', 0, NULL, '{"reuniao_id": 2, "numero": 1, "ano": 2026}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:35:00');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (19, 1, 'Jurandi de Melo Barros', 'editar', 'ata', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:37:02');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (20, 1, 'Jurandi de Melo Barros', 'assinar', 'ata', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:39:11');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (21, 1, 'Jurandi de Melo Barros', 'editar', 'ata', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 15:58:10');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (22, 1, 'Jurandi de Melo Barros', 'criar', 'reuniao', 0, NULL, '{"titulo": "Sessão Ordinária", "data": "2026-03-23", "tipo": "Iniciação"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 16:02:01');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (23, 1, 'Jurandi de Melo Barros', 'criar', 'reuniao', 0, NULL, '{"titulo": "Sessão Ordinária", "data": "2026-03-23", "tipo": "Ordinária"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 16:08:50');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (24, 1, 'Jurandi de Melo Barros', 'criar', 'ata', 0, NULL, '{"reuniao_id": 4, "numero": 2, "ano": 2026}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 16:20:55');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (25, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 16:35:53');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (26, 1, 'Jurandi de Melo Barros', 'criar', 'obreiro', 0, NULL, '{"nome": "Felipe Formiga De Holanda Santos ", "usuario": "felipe"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 16:56:43');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (27, 1, 'Jurandi de Melo Barros', 'criar', 'obreiro', 0, NULL, '{"nome": "Charles Douglas Protazio Sousa", "usuario": "charles"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 16:57:52');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (28, 1, 'Jurandi de Melo Barros', 'editar', 'loja', 2, '{"id": 2, "nome": "Bicentenário", "numero": "4739", "oriente": "Ceilândia", "cidade": "Ceilândia", "estado": "DF", "data_fundacao": "2022-06-26", "endereco": null, "bairro": null, "cep": null, "telefone": null, "email": null, "site": null, "data_instalacao": null, "data_autorizacao": null, "veneravel_mestre": null, "secretario": null, "tesoureiro": null, "orador": null, "horario_reuniao": null, "dia_reuniao": null, "rito": null, "observacoes": null, "logo": null, "ativo": 1}', '{"nome": "Bicentenário", "numero": "4739"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 17:53:41');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (29, 1, 'Jurandi de Melo Barros', 'criar_sugestao', 'sugestao', 0, NULL, '{"titulo": "Adicionar os aniversários dos familiares", "categoria": "melhoria_sistema"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 17:54:57');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (30, 1, 'Jurandi de Melo Barros', 'criar', 'comunicado', 0, NULL, '{"titulo": "Aviso geral", "prioridade": "importante"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 18:04:25');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (31, 1, 'Jurandi de Melo Barros', 'editar', 'comunicado', 1, '{"id": 1, "titulo": "Aviso geral", "conteudo": "Aviso geral pra galera", "tipo": "aviso", "prioridade": "importante", "data_inicio": "2026-03-23", "data_fim": null, "ativo": 1, "criado_por": 1, "data_criacao": "2026-03-23 18:04:25.833991"}', '{"titulo": "Aviso geral", "prioridade": "importante"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 18:06:49');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (32, 1, 'Jurandi de Melo Barros', 'editar', 'cargo', 14, '{"id": 14, "nome": "Hospitaleiro", "sigla": "HOSP", "grau_minimo": 1, "ordem": 14, "descricao": "Responsável pelo ágape", "ativo": 1}', '{"nome": "Hospitaleiro", "sigla": "HOSP"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 18:07:15');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (33, 1, 'Jurandi de Melo Barros', 'editar', 'tipo_ausencia', 8, '{"id": 8, "nome": "Doença na Família", "descricao": "Acompanhamento familiar", "requer_comprovante": 1, "cor": "#fd7e14", "ativo": 1}', '{"nome": "Doença na Família"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 18:07:31');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (34, 1, 'Jurandi de Melo Barros', 'testar_whatsapp', 'whatsapp', NULL, NULL, '{"numero": "5561993681248"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 18:09:49');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (35, 1, 'Jurandi de Melo Barros', 'criar_familiar', 'familiar', 0, NULL, '{"nome": "Marta Nogueira Barros", "parentesco": "esposa"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 19:17:07');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (36, 1, 'Jurandi de Melo Barros', 'conceder_condecoracao', 'condecoracao', 0, NULL, '{"obreiro_id": 6, "tipo_id": "5"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 19:38:49');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (37, 1, 'Jurandi de Melo Barros', 'atribuir_cargo', 'cargo', 7, NULL, '{"obreiro_id": 6, "cargo_id": "7"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 20:00:12');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (38, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:00:00');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (39, 1, 'Jurandi de Melo Barros', 'criar', 'obreiro', 0, NULL, '{"nome": "Renato Maximino", "usuario": "Renato"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:01:04');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (40, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:01:17');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (43, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:02:37');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (44, 1, 'Jurandi de Melo Barros', 'criar', 'obreiro', 0, NULL, '{"nome": "Jairo", "usuario": "jairo"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:03:06');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (45, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:03:12');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (46, 8, 'Jairo', 'login', 'usuarios', 8, NULL, '{"usuario": "jairo"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:03:14');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (47, 8, 'Jairo', 'logout', 'usuarios', 8, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:03:39');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (48, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:22:47');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (49, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:22:55');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (50, 7, 'Renato Maximino', 'login', 'usuarios', 7, NULL, '{"usuario": "Renato"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:23:08');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (51, 7, 'Renato Maximino', 'assinar', 'ata', 2, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:25:51');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (52, 7, 'Renato Maximino', 'logout', 'usuarios', 7, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:42:08');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (53, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:42:18');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (54, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:45:23');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (55, 7, 'Renato Maximino', 'login', 'usuarios', 7, NULL, '{"usuario": "Renato"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:45:26');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (56, 7, 'Renato Maximino', 'logout', 'usuarios', 7, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:45:36');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (57, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:45:39');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (58, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:46:10');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (59, 7, 'Renato Maximino', 'login', 'usuarios', 7, NULL, '{"usuario": "Renato"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:46:15');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (60, 7, 'Renato Maximino', 'logout', 'usuarios', 7, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:47:03');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (61, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:47:07');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (62, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:47:58');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (63, 8, 'Jairo', 'login', 'usuarios', 8, NULL, '{"usuario": "jairo"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:48:08');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (64, 8, 'Jairo', 'logout', 'usuarios', 8, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:49:12');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (65, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-23 23:49:16');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (66, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:24:37');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (67, 6, 'Charles Douglas Protazio Sousa', 'login', 'usuarios', 6, NULL, '{"usuario": "charles"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:24:41');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (68, 6, 'Charles Douglas Protazio Sousa', 'logout', 'usuarios', 6, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:25:12');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (69, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:25:17');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (70, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:26:32');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (71, 6, 'Charles Douglas Protazio Sousa', 'login', 'usuarios', 6, NULL, '{"usuario": "charles"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:26:37');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (72, 6, 'Charles Douglas Protazio Sousa', 'logout', 'usuarios', 6, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:27:38');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (73, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:27:42');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (74, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 3}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:28:12');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (75, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:28:17');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (76, 6, 'Charles Douglas Protazio Sousa', 'login', 'usuarios', 6, NULL, '{"usuario": "charles"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:28:20');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (77, 6, 'Charles Douglas Protazio Sousa', 'logout', 'usuarios', 6, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:28:27');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (78, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 00:28:30');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (79, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:34:20');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (80, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:34:22');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (81, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 2, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:34:44');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (82, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 4, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:35:07');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (83, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 2, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:35:29');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (84, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 4, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:47:01');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (85, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:47:22');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (86, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 4, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:47:37');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (87, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 3, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:48:03');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (88, 1, 'Jurandi de Melo Barros', 'editar', 'obreiro', 6, '{"id": 6, "usuario": "charles", "senha_hash": "scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1", "tipo": "obreiro", "data_cadastro": "2026-03-23 16:57:52.580964", "nome_completo": "Charles Douglas Protazio Sousa", "nome_maconico": "Charles", "cim_numero": "", "grau_atual": 4, "data_iniciacao": null, "data_elevacao": null, "data_exaltacao": null, "telefone": "", "email": "", "endereco": "", "loja_nome": "Bicentenário", "loja_numero": "4739", "loja_orient": "Ceilândia", "ativo": 1, "nivel_acesso": 2}', '{"nome": "Charles Douglas Protazio Sousa", "email": "", "telefone": ""}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:54:28');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (89, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:55:04');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (90, 6, 'Charles Douglas Protazio Sousa', 'login', 'usuarios', 6, NULL, '{"usuario": "charles"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:55:08');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (91, 6, 'Charles Douglas Protazio Sousa', 'logout', 'usuarios', 6, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:55:21');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (92, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 07:55:24');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (93, 6, 'Charles Douglas Protazio Sousa', 'login', 'usuarios', 6, NULL, '{"usuario": "charles"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 08:03:57');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (94, 6, 'Charles Douglas Protazio Sousa', 'logout', 'usuarios', 6, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 08:08:14');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (95, 5, 'Felipe Formiga De Holanda Santos ', 'login', 'usuarios', 5, NULL, '{"usuario": "felipe"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 08:08:18');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (96, 5, 'Felipe Formiga De Holanda Santos ', 'logout', 'usuarios', 5, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 08:08:27');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (97, 6, 'Charles Douglas Protazio Sousa', 'login', 'usuarios', 6, NULL, '{"usuario": "charles"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 08:08:32');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (98, 6, 'Charles Douglas Protazio Sousa', 'logout', 'usuarios', 6, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 09:15:49');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (99, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 09:15:52');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (100, 8, 'Jairo', 'login', 'usuarios', 8, NULL, '{"usuario": "jairo"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 09:23:19');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (101, 8, 'Jairo', 'logout', 'usuarios', 8, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 09:24:27');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (102, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 09:24:35');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (103, 1, 'Jurandi de Melo Barros', 'logout', 'usuarios', 1, NULL, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 11:18:01');
INSERT INTO logs_auditoria (id, usuario_id, usuario_nome, acao, entidade, entidade_id, dados_anteriores, dados_novos, ip, user_agent, data_hora) VALUES (104, 1, 'Jurandi de Melo Barros', 'login', 'usuarios', 1, NULL, '{"usuario": "admin"}', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-24 11:18:04');

-- Dados da tabela: lojas
DELETE FROM lojas;

INSERT INTO lojas (id, nome, numero, oriente, cidade, estado, data_fundacao, endereco, bairro, cep, telefone, email, site, data_instalacao, data_autorizacao, veneravel_mestre, secretario, tesoureiro, orador, horario_reuniao, dia_reuniao, rito, observacoes, logo, ativo) VALUES (2, 'Bicentenário', '4739', 'Ceilândia', 'Ceilândia', 'DF', 2022-06-26, 'Qnm 38', 'Ceilândia', '', '', '', '', NULL, NULL, 'Reynaldo Aben-Athar', 'Jurandi de Melo Barros', 'Felipe Formiga', 'Esmeraldino', 09:00:00, 'Sábado', 'Rito Brasileiro', '', NULL, 1);

-- Dados da tabela: modelos_ata
DELETE FROM modelos_ata;

INSERT INTO modelos_ata (id, nome, descricao, tipo, estrutura, campos_personalizados, ativo, created_at, created_by) VALUES (1, 'Ata Ordinária', 'Modelo padrão para reuniões ordinárias', 'Ordinária', '{"cabecalho": ["Abertura", "Verificacao de quorum", "Leitura da ata anterior"], "expediente": ["Comunicacoes", "Propostas", "Informacoes"], "ordem_do_dia": ["Assuntos em pauta", "Votacoes", "Deliberacoes"], "encerramento": ["Palavra final", "Marcacao proxima reuniao", "Encerramento"]}', NULL, 1, '2026-03-23 13:26:44', NULL);
INSERT INTO modelos_ata (id, nome, descricao, tipo, estrutura, campos_personalizados, ativo, created_at, created_by) VALUES (2, 'Ata Magna', 'Modelo para reunioes magnas', 'Magna', '{"cabecalho": ["Abertura solene", "Composicao da mesa", "Hino"], "expediente": ["Comunicacoes oficiais", "Propostas especiais"], "ordem_do_dia": ["Rituais", "Iniciacoes", "Elevacoes", "Exaltacoes"], "encerramento": ["Palavra do Veneravel", "Encerramento solene"]}', NULL, 1, '2026-03-23 13:26:44', NULL);
INSERT INTO modelos_ata (id, nome, descricao, tipo, estrutura, campos_personalizados, ativo, created_at, created_by) VALUES (3, 'Ata Administrativa', 'Modelo para reunioes administrativas', 'Administrativa', '{"cabecalho": ["Abertura", "Presentes", "Pauta"], "expediente": ["Prestacao de contas", "Assuntos financeiros"], "ordem_do_dia": ["Deliberacoes", "Votacoes", "Planejamento"], "encerramento": ["Encaminhamentos", "Proxima reuniao", "Encerramento"]}', NULL, 1, '2026-03-23 13:26:44', NULL);

-- Dados da tabela: modulos
DELETE FROM modulos;

INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (1, 'Dashboard', 'Painel principal do sistema', 'bi-speedometer2', 1, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (2, 'Candidatos', 'Gestão de candidatos', 'bi-people', 2, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (3, 'Sindicantes', 'Gestão de sindicantes', 'bi-person-badge', 3, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (4, 'Obreiros', 'Gestão de obreiros', 'bi-person-workspace', 4, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (5, 'Reuniões', 'Gestão de reuniões', 'bi-calendar-event', 5, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (6, 'Atas', 'Gestão de atas', 'bi-file-text', 6, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (7, 'Comunicados', 'Gestão de comunicados', 'bi-megaphone', 7, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (8, 'Cargos', 'Gestão de cargos', 'bi-briefcase', 8, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (9, 'Graus', 'Gestão de graus', 'bi-star-fill', 9, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (10, 'Lojas', 'Gestão de lojas', 'bi-building', 10, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (11, 'Familiares', 'Gestão de familiares', 'bi-people', 11, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (12, 'Condecorações', 'Gestão de condecorações', 'bi-award', 12, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (13, 'Auditoria', 'Logs do sistema', 'bi-journal', 13, 1);
INSERT INTO modulos (id, nome, descricao, icone, ordem, ativo) VALUES (14, 'Configurações', 'Configurações do sistema', 'bi-gear', 14, 1);

-- Dados da tabela: notificacoes_log
DELETE FROM notificacoes_log;

INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (1, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 21:42:44', '[WinError 10054] Foi forçado o cancelamento de uma conexão existente pelo host remoto');
INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (2, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 21:43:01', '[WinError 10054] Foi forçado o cancelamento de uma conexão existente pelo host remoto');
INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (3, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 21:44:32', '[WinError 10054] Foi forçado o cancelamento de uma conexão existente pelo host remoto');
INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (4, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 21:45:44', '[WinError 10054] Foi forçado o cancelamento de uma conexão existente pelo host remoto');
INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (5, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 21:47:02', '[WinError 10054] Foi forçado o cancelamento de uma conexão existente pelo host remoto');
INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (6, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 22:24:07', '[WinError 10054] Foi forçado o cancelamento de uma conexão existente pelo host remoto');
INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (7, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 22:32:54', '[WinError 10054] Foi forçado o cancelamento de uma conexão existente pelo host remoto');
INSERT INTO notificacoes_log (id, destinatario, assunto, corpo, tipo, status, data_envio, erro) VALUES (8, 'jurandibarros@gmail.com', 'Teste de Configuração - Sistema Maçônico', '', 'email', 'erro', '2026-03-23 22:33:09', '[Errno 11001] getaddrinfo failed');

-- Dados da tabela: ocupacao_cargos
DELETE FROM ocupacao_cargos;

INSERT INTO ocupacao_cargos (id, obreiro_id, cargo_id, loja_id, data_inicio, data_fim, gestao, ativo) VALUES (1, 6, 7, NULL, 2026-03-23, NULL, NULL, 1);

-- Dados da tabela: pareceres_conclusivos
DELETE FROM pareceres_conclusivos;

-- Dados da tabela: permissoes
DELETE FROM permissoes;

INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (1, 1, 'Ver Dashboard', 'dashboard.view', 'Visualizar o painel principal');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (2, 2, 'Ver Candidatos', 'candidatos.view', 'Visualizar lista de candidatos');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (3, 2, 'Criar Candidato', 'candidatos.create', 'Adicionar novo candidato');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (4, 2, 'Editar Candidato', 'candidatos.edit', 'Editar dados do candidato');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (5, 2, 'Excluir Candidato', 'candidatos.delete', 'Excluir candidato');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (6, 3, 'Ver Sindicantes', 'sindicantes.view', 'Visualizar lista de sindicantes');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (7, 3, 'Criar Sindicante', 'sindicantes.create', 'Adicionar novo sindicante');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (8, 3, 'Editar Sindicante', 'sindicantes.edit', 'Editar dados do sindicante');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (9, 3, 'Excluir Sindicante', 'sindicantes.delete', 'Excluir sindicante');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (10, 4, 'Ver Obreiros', 'obreiros.view', 'Visualizar lista de obreiros');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (11, 4, 'Criar Obreiro', 'obreiros.create', 'Adicionar novo obreiro');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (12, 4, 'Editar Obreiro', 'obreiros.edit', 'Editar dados do obreiro');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (13, 4, 'Excluir Obreiro', 'obreiros.delete', 'Excluir obreiro');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (14, 4, 'Ver Familiares', 'familiares.view', 'Visualizar familiares do obreiro');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (15, 4, 'Gerenciar Familiares', 'familiares.manage', 'Adicionar/editar/excluir familiares');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (16, 4, 'Ver Condecorações', 'condecoracoes.view', 'Visualizar condecorações do obreiro');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (17, 4, 'Gerenciar Condecorações', 'condecoracoes.manage', 'Adicionar/editar/excluir condecorações');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (18, 5, 'Ver Reuniões', 'reunioes.view', 'Visualizar lista de reuniões');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (19, 5, 'Criar Reunião', 'reunioes.create', 'Agendar nova reunião');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (20, 5, 'Editar Reunião', 'reunioes.edit', 'Editar dados da reunião');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (21, 5, 'Excluir Reunião', 'reunioes.delete', 'Excluir reunião');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (22, 5, 'Registrar Presença', 'presenca.registrar', 'Registrar presença em reuniões');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (23, 6, 'Ver Atas', 'atas.view', 'Visualizar lista de atas');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (24, 6, 'Criar Ata', 'atas.create', 'Criar nova ata');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (25, 6, 'Editar Ata', 'atas.edit', 'Editar ata');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (26, 6, 'Aprovar Ata', 'atas.approve', 'Aprovar ata');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (27, 6, 'Assinar Ata', 'atas.sign', 'Assinar ata');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (28, 7, 'Ver Comunicados', 'comunicados.view', 'Visualizar comunicados');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (29, 7, 'Criar Comunicado', 'comunicados.create', 'Publicar novo comunicado');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (30, 7, 'Editar Comunicado', 'comunicados.edit', 'Editar comunicado');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (31, 7, 'Excluir Comunicado', 'comunicados.delete', 'Excluir comunicado');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (32, 8, 'Ver Cargos', 'cargos.view', 'Visualizar lista de cargos');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (33, 8, 'Gerenciar Cargos', 'cargos.manage', 'Criar/editar/excluir cargos');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (34, 9, 'Ver Graus', 'graus.view', 'Visualizar lista de graus');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (35, 9, 'Gerenciar Graus', 'graus.manage', 'Criar/editar/excluir graus');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (36, 10, 'Ver Lojas', 'lojas.view', 'Visualizar lista de lojas');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (37, 10, 'Gerenciar Lojas', 'lojas.manage', 'Criar/editar/excluir lojas');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (38, 13, 'Ver Logs', 'auditoria.view', 'Visualizar logs de auditoria');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (39, 13, 'Exportar Logs', 'auditoria.export', 'Exportar logs');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (40, 14, 'Ver Configurações', 'config.view', 'Visualizar configurações');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (41, 14, 'Gerenciar Permissões', 'config.permissions', 'Gerenciar permissões do sistema');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (42, 14, 'Configurar Email', 'config.email', 'Configurar envio de e-mails');
INSERT INTO permissoes (id, modulo_id, nome, codigo, descricao) VALUES (43, 14, 'Configurar WhatsApp', 'config.whatsapp', 'Configurar notificações WhatsApp');

-- Dados da tabela: permissoes_grau
DELETE FROM permissoes_grau;

INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (162, 1, 1);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (163, 1, 10);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (164, 1, 18);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (165, 1, 23);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (166, 1, 28);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (80, 2, 1);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (84, 7, 3);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (87, 3, 1);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (88, 3, 2);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (89, 3, 3);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (90, 3, 4);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (91, 3, 5);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (92, 3, 6);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (93, 3, 7);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (94, 3, 8);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (95, 3, 9);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (96, 3, 10);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (97, 3, 11);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (98, 3, 12);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (99, 3, 13);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (100, 3, 14);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (101, 3, 15);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (102, 3, 16);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (103, 3, 17);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (104, 3, 18);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (105, 3, 19);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (106, 3, 20);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (107, 3, 21);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (108, 3, 22);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (109, 3, 23);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (110, 3, 24);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (111, 3, 25);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (112, 3, 26);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (113, 3, 27);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (114, 3, 28);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (115, 3, 29);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (116, 3, 30);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (117, 3, 31);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (118, 3, 32);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (119, 3, 33);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (120, 3, 34);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (121, 3, 35);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (122, 3, 36);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (123, 3, 37);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (124, 3, 38);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (125, 3, 39);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (126, 3, 40);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (127, 3, 41);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (128, 3, 42);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (129, 3, 43);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (130, 4, 1);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (131, 4, 2);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (132, 4, 3);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (133, 4, 6);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (134, 4, 10);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (135, 4, 11);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (136, 4, 12);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (137, 4, 14);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (138, 4, 15);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (139, 4, 16);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (140, 4, 17);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (141, 4, 18);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (142, 4, 19);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (143, 4, 20);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (144, 4, 22);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (145, 4, 23);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (146, 4, 24);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (147, 4, 25);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (148, 4, 26);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (149, 4, 27);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (150, 4, 28);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (151, 4, 29);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (152, 4, 30);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (153, 4, 31);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (154, 4, 32);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (155, 4, 33);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (156, 4, 34);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (157, 4, 35);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (158, 4, 36);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (159, 4, 37);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (160, 4, 38);
INSERT INTO permissoes_grau (id, grau_id, permissao_id) VALUES (161, 4, 40);

-- Dados da tabela: permissoes_usuario
DELETE FROM permissoes_usuario;

INSERT INTO permissoes_usuario (id, usuario_id, permissao_id, permitido) VALUES (1, 7, 1, 0);
INSERT INTO permissoes_usuario (id, usuario_id, permissao_id, permitido) VALUES (2, 8, 1, 0);

-- Dados da tabela: preferencias_notificacao
DELETE FROM preferencias_notificacao;

-- Dados da tabela: presenca
DELETE FROM presenca;

-- Dados da tabela: reunioes
DELETE FROM reunioes;

INSERT INTO reunioes (id, titulo, tipo, grau, data, hora_inicio, hora_termino, local, loja_id, pauta, observacoes, status, data_criacao, criado_por) VALUES (2, 'Sessão Ordinária', 'Exaltação', 3, 2026-03-23, 19:30:00, 22:00:00, 'QNM 38', 2, '## PAUTA DA REUNIÃO

**Data:** 22/03/2026
**Horário:** 19:30

---', 'Assuntos aleatórios', 'realizada', '2026-03-23 15:23:28', 1);
INSERT INTO reunioes (id, titulo, tipo, grau, data, hora_inicio, hora_termino, local, loja_id, pauta, observacoes, status, data_criacao, criado_por) VALUES (3, 'Sessão Ordinária', 'Iniciação', 1, 2026-03-23, 19:30:00, 22:00:00, 'QNM 38', 2, '## PAUTA DA REUNIÃO

**Data:** 22/03/2026
**Horário:** 19:30

---', 'Iniciação', 'agendada', '2026-03-23 16:02:00', 1);
INSERT INTO reunioes (id, titulo, tipo, grau, data, hora_inicio, hora_termino, local, loja_id, pauta, observacoes, status, data_criacao, criado_por) VALUES (4, 'Sessão Ordinária', 'Ordinária', 1, 2026-03-23, 19:30:00, 22:00:00, NULL, 2, '## PAUTA DA REUNIÃO

**Data:** 22/03/2026
**Horário:** 19:30

---', 'ttt', 'agendada', '2026-03-23 16:08:50', 1);

-- Dados da tabela: sindicancias
DELETE FROM sindicancias;

-- Dados da tabela: sugestoes
DELETE FROM sugestoes;

INSERT INTO sugestoes (id, titulo, descricao, categoria, prioridade, status, autor_id, votos, implementada, data_implementacao, implementado_por, data_criacao, data_atualizacao) VALUES (1, 'Adicionar os aniversários dos familiares', 'Adicionar os aniversários dos familiares', 'melhoria_sistema', 'media', 'pendente', 1, 0, 0, NULL, NULL, '2026-03-23 17:54:57', '2026-03-23 17:54:57');

-- Dados da tabela: teste_conexao
DELETE FROM teste_conexao;

INSERT INTO teste_conexao (id, nome, data_criacao) VALUES (1, 'Teste de conexão', '2026-03-23 12:44:50');

-- Dados da tabela: tipos_ausencia
DELETE FROM tipos_ausencia;

INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (1, 'Justificada', 'Ausência justificada por motivo pessoal', 0, '#28a745', 1);
INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (2, 'Injustificada', 'Ausência sem justificativa', 0, '#dc3545', 1);
INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (3, 'Licença Saúde', 'Licença médica ou problema de saúde', 1, '#ffc107', 1);
INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (4, 'Licença Profissional', 'Compromisso profissional inadiável', 1, '#17a2b8', 1);
INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (5, 'Licença Particular', 'Assuntos particulares', 1, '#6c757d', 1);
INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (6, 'Viagem', 'Viagem a trabalho ou pessoal', 1, '#6610f2', 1);
INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (7, 'Luto', 'Falecimento de familiar', 1, '#6c757d', 1);
INSERT INTO tipos_ausencia (id, nome, descricao, requer_comprovante, cor, ativo) VALUES (8, 'Doença na Família', 'Acompanhamento familiar ', 1, '#fd7e14', 1);

-- Dados da tabela: tipos_condecoracoes
DELETE FROM tipos_condecoracoes;

INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (1, 'Medalha do Mérito Maçônico', 'Reconhecimento por serviços prestados à Maçonaria', 1, '#ffc107', 'bi-award', 1, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (2, 'Medalha do Mérito Cultural', 'Contribuição para a cultura e educação', 2, '#17a2b8', 'bi-book', 2, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (3, 'Medalha do Mérito Social', 'Trabalhos sociais e filantrópicos', 2, '#28a745', 'bi-heart', 3, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (4, 'Medalha do Mérito Científico', 'Contribuições científicas e acadêmicas', 3, '#6f42c1', 'bi-flask', 4, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (5, 'Colar do Mérito', 'Máxima honraria da Loja', 4, '#dc3545', 'bi-star-fill', 5, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (6, 'Diploma de Honra ao Mérito', 'Reconhecimento especial', 3, '#fd7e14', 'bi-file-text', 6, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (7, 'Carta de Reconhecimento', 'Agradecimento por serviços relevantes', 2, '#20c997', 'bi-envelope', 7, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (8, 'Título de Benemérito', 'Contribuições excepcionais', 4, '#e83e8c', 'bi-trophy', 8, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (9, 'Medalha da Fraternidade', 'Espírito de fraternidade e união', 2, '#007bff', 'bi-people', 9, 1, '2026-03-23 19:29:23');
INSERT INTO tipos_condecoracoes (id, nome, descricao, nivel, cor, icone, ordem, ativo, created_at) VALUES (10, 'Insígnia do Trabalho', 'Dedicação ao trabalho maçônico', 1, '#6c757d', 'bi-briefcase', 10, 1, '2026-03-23 19:29:23');

-- Dados da tabela: tipos_reuniao
DELETE FROM tipos_reuniao;

INSERT INTO tipos_reuniao (id, nome, descricao, cor) VALUES (1, 'Ordinária', 'Reunião ordinária semanal/mensal', '#28a745');
INSERT INTO tipos_reuniao (id, nome, descricao, cor) VALUES (2, 'Magna', 'Reunião magna solene', '#dc3545');
INSERT INTO tipos_reuniao (id, nome, descricao, cor) VALUES (3, 'Extraordinária', 'Reunião extraordinária convocada', '#ffc107');
INSERT INTO tipos_reuniao (id, nome, descricao, cor) VALUES (4, 'Administrativa', 'Reunião da administração', '#17a2b8');
INSERT INTO tipos_reuniao (id, nome, descricao, cor) VALUES (5, 'Iniciação', 'Sessão de iniciação de novos obreiros', '#6610f2');
INSERT INTO tipos_reuniao (id, nome, descricao, cor) VALUES (6, 'Elevação', 'Sessão de elevação ao grau de Companheiro', '#fd7e14');
INSERT INTO tipos_reuniao (id, nome, descricao, cor) VALUES (7, 'Exaltação', 'Sessão de exaltação ao grau de Mestre', '#20c997');

-- Dados da tabela: usuarios
DELETE FROM usuarios;

INSERT INTO usuarios (id, usuario, senha_hash, tipo, data_cadastro, nome_completo, nome_maconico, cim_numero, grau_atual, data_iniciacao, data_elevacao, data_exaltacao, telefone, email, endereco, loja_nome, loja_numero, loja_orient, ativo, nivel_acesso) VALUES (5, 'felipe', 'scrypt:32768:8:1$vwSqy6MA17UJaLSQ$b9422da539e8d66953434870c990ffdff8b991ecedc016e410a032e70ec018f9056cf6ca750add767aa4319fd9bc54fddfb0c07d7a2c8b888589fbcdc78683c9', 'sindicante', '2026-03-23 16:56:43', 'Felipe Formiga De Holanda Santos ', 'Felipe Formiga', '223.125', 3, NULL, NULL, NULL, '', '', '', 'Bicentenário', '4739', 'Ceilândia', 1, 3);
INSERT INTO usuarios (id, usuario, senha_hash, tipo, data_cadastro, nome_completo, nome_maconico, cim_numero, grau_atual, data_iniciacao, data_elevacao, data_exaltacao, telefone, email, endereco, loja_nome, loja_numero, loja_orient, ativo, nivel_acesso) VALUES (7, 'Renato', 'scrypt:32768:8:1$wX40LdmHzbWN2WJl$ef8e729fddd8b710787370a25007ad3505a02fbc28bdeb0e0e24f12990e7b5131f0731b2054f54e6d8cf1e81a8ed97d8dd2883191eaac1c8f987b7e1797a47cd', 'obreiro', '2026-03-23 23:01:04', 'Renato Maximino', 'Renato', '', 3, NULL, NULL, NULL, '', '', '', 'Bicentenário', '4739', 'Ceilândia', 1, 3);
INSERT INTO usuarios (id, usuario, senha_hash, tipo, data_cadastro, nome_completo, nome_maconico, cim_numero, grau_atual, data_iniciacao, data_elevacao, data_exaltacao, telefone, email, endereco, loja_nome, loja_numero, loja_orient, ativo, nivel_acesso) VALUES (8, 'jairo', 'scrypt:32768:8:1$WSmS9RSfVEXJHZ6p$46f570d59498daab911ab5076631a7a69d430d28a25f344f5ce16da8616042dc55e1b184885f248e906377fdf27a20712000864760e599a6bd0add054d7f0955', 'obreiro', '2026-03-23 23:03:06', 'Jairo', 'jairo', '', 1, NULL, NULL, NULL, '', '', '', 'Bicentenário', '4739', 'Ceilândia', 1, 1);
INSERT INTO usuarios (id, usuario, senha_hash, tipo, data_cadastro, nome_completo, nome_maconico, cim_numero, grau_atual, data_iniciacao, data_elevacao, data_exaltacao, telefone, email, endereco, loja_nome, loja_numero, loja_orient, ativo, nivel_acesso) VALUES (1, 'admin', 'scrypt:32768:8:1$SrL2i1H9QSyC2F90$576e559fa8e1c0a01bbf9f06a6dee06260f2e1431e9df69b08aaf25a9cbd5a62172cd792d1d30ab1da76329f4b62f1fe3f334778fd8d90121ca3757e8616bcb3', 'admin', '2026-03-23 13:26:44', 'Jurandi de Melo Barros', 'Jurandi', '339.652', 3, NULL, NULL, NULL, '(61) 99368-1248', 'jurandibarros@gmail.com', 'QNQ 02 Conjunto 18 Casa 19', 'Bicentenário', '4739', 'Ceilândia', 1, 4);
INSERT INTO usuarios (id, usuario, senha_hash, tipo, data_cadastro, nome_completo, nome_maconico, cim_numero, grau_atual, data_iniciacao, data_elevacao, data_exaltacao, telefone, email, endereco, loja_nome, loja_numero, loja_orient, ativo, nivel_acesso) VALUES (6, 'charles', 'scrypt:32768:8:1$jiLbpA5XzFR4M4RJ$7550c5de273a2d30005b401ab5dc5e0c9c13eb4ea2d6766cd63cd31302b429df1f75bbf6a60fa05a307acc61d2ccc2923da88bd073a73d25bc425ce5c81048a1', 'obreiro', '2026-03-23 16:57:52', 'Charles Douglas Protazio Sousa', 'Charles', '', 3, NULL, NULL, NULL, '', '', '', 'Bicentenário', '4739', 'Ceilândia', 1, 3);

-- Dados da tabela: visualizacoes_comunicado
DELETE FROM visualizacoes_comunicado;

INSERT INTO visualizacoes_comunicado (id, comunicado_id, obreiro_id, data_visualizacao) VALUES (1, 1, 7, '2026-03-23 23:23:26');

-- Dados da tabela: votos_sugestao
DELETE FROM votos_sugestao;

-- Dados da tabela: whatsapp_config
DELETE FROM whatsapp_config;

INSERT INTO whatsapp_config (id, notificar_ausencia, notificar_nova_reuniao, notificar_comunicado, lembrete_reuniao, grupo_id, updated_at) VALUES (1, 1, 1, 1, 1, NULL, '2026-03-23 13:26:44');

